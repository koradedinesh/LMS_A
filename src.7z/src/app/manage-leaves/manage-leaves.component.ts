import { Component, OnInit } from '@angular/core';
import { LeaveDetails } from './../model/LeaveDetails';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-manage-leaves',
  templateUrl: './manage-leaves.component.html',
  styleUrls: ['./manage-leaves.component.scss']
})
export class ManageLeavesComponent implements OnInit {

  isNotAcceptedOrRejected: boolean = true;

  pendingLeaveRequests: Array<LeaveDetails> = []

  private headers: HttpHeaders = new HttpHeaders({
    'Content-Type': 'application/json'
  });

  private options = {
    headers: this.headers
  }

  get haveRecords(): boolean {
    return this.pendingLeaveRequests.length > 0;
  }

  constructor(private _loginService: LoginService,
    private _router: Router,
    private _http: HttpClient) { }

  ngOnInit(): void {
    if (!this._loginService.isLoggedIn) {
      this._router.navigate(['login']);
    }
    this.getPendingLeaves();
  }

  getPendingLeaves() {
    this._http.get<Array<Map<String, LeaveDetails[]>>>("http://localhost:8011/getPendingLeaves")
      .subscribe(response => {
        response.forEach((entry: Map<String, Array<LeaveDetails>>) => {
          for (let [key, value] of Object.entries(entry)) {
            value.forEach(element => {
              element.username = key;
              console.log(element )
              this.pendingLeaveRequests.push(element);
            });
          }
        })
      });
  }

  approve(detail: LeaveDetails): void {
    this._http.post<any>("http://localhost:8011/approveLeaveRequest?username=" + detail.username +"&status=approve", JSON.stringify(detail), this.options)
      .subscribe(response => {
        if(response === null) {
          alert("Failed to Approve Request. Leave Quota Expired!");
        }
        this.removeFromList(detail);
      },
      error => console.log(error));
  }

  reject(detail: LeaveDetails): void {
    this._http.post<any>("http://localhost:8011/rejectLeaveRequest?status=rejected", JSON.stringify(detail), this.options)
      .subscribe(response => {
        this.removeFromList(detail);
      });
  }

  removeFromList(detail: LeaveDetails): void {
    this.pendingLeaveRequests.splice(this.pendingLeaveRequests.indexOf(detail), 1);
  }

}
