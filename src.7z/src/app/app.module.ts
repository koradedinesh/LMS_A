import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SignupComponent } from './signup/signup.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ManageLeavesComponent } from './manage-leaves/manage-leaves.component';
import { ApplyLeaveComponent } from './apply-leave/apply-leave.component';
import { LoginService} from './login.service';
import { HistoryComponent } from './history/history.component';
import { HttpClientModule } from '@angular/common/http';
import { DatePipe, HashLocationStrategy } from '@angular/common';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    NavbarComponent,
    ManageLeavesComponent,
    ApplyLeaveComponent,
    HistoryComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [ LoginService, DatePipe, HashLocationStrategy ],
  bootstrap: [AppComponent]
})
export class AppModule { }
