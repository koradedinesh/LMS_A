import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';
import { LeaveDetails } from '../model/LeaveDetails';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.scss']
})
export class HistoryComponent implements OnInit {

  leaves: Array<LeaveDetails> = []

  get haveRecords(): boolean {
    return this.leaves.length > 0;
  }

  constructor(private _loginService: LoginService,
    private _router: Router,
    private _http: HttpClient) {
      
    }

  ngOnInit() {
    if(!this._loginService.isLoggedIn) {
      this._router.navigate(['login']);
    } else {
      this._http.get<LeaveDetails[]>("http://localhost:8011/getLeaveDetailsHistory?personId=" + this._loginService.userId)
        .subscribe(response => {
          this.leaves = response;
        })
    }
  }
}
