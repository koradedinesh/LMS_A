import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {

  constructor(private _loginService: LoginService,
    private _router: Router) { }

  get isLoggedIn() {
    return this._loginService.isLoggedIn;
  }

  get username() {
    return this._loginService.username;
  }

  ngOnInit(): void {
  }

  get isManager() {
    return this._loginService.role === "Head";
  }

  logout() {
    this._loginService.endSession();
    this._router.navigate(['login']);
  }

}
