import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {

  username: string;
  password: string;
  role: string = "Employee";
  empId: string;

  private headers: HttpHeaders = new HttpHeaders({
    'Content-Type': 'application/json'
  });

  private options = {
    headers: this.headers
  }

  constructor(private _loginService: LoginService,
    private _router: Router,
    private _http: HttpClient) { }

  ngOnInit(): void {
  }

  signup(): void {
    let person = {
      username: this.username,
      password: this.password,
      role: this.role,
      personId: this.empId
    }
    this._http.post<any>("http://localhost:8011/savePerson", JSON.stringify(person), this.options)
      .subscribe(response => {
        this._loginService.setPerson(person);
        this._router.navigate(['home']);
      });
  }

}
