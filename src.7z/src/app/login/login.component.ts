import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { LoginService } from '../login.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  empid: string;
  password: string;

  incorrect: boolean = false;

  constructor(private _loginService: LoginService,
    private _http: HttpClient,
    private _router: Router) { }

  ngOnInit(): void {
    this._loginService.setLoggedIn(false);
  }

  login(): void {
    this._http.get<any>("http://localhost:8011/getPersonByIdAndPassword?personId=" + this.empid + "&&password=" + this.password)
      .subscribe(data => {
        this._loginService.setPerson({
          personId: data.personId,
          username: data.username,
          role: data.role,
          password: ''
        });
        
        this._loginService.setLoggedIn(true);
        this._router.navigate(['home']);
      },
      error => {
        this.handleLoginError();
      });
  }

  handleLoginError(): void {
    this.incorrect = true;
    setTimeout(() => {
      this.empid = undefined;
      this.password = undefined;
      this.incorrect = false;
    }, 3000);
  }

}
