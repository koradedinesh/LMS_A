import { Person } from './Person';

export interface LeaveDetails {
    comment: string
    leaveFrom: string
    leaveTo: string
    reason: string
    requestId: string
    status: string
    submittedOn: string
    username: string
    numberOfLeavesApplied: number
}