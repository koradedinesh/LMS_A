import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AppComponent } from './app.component';
import { SignupComponent } from './signup/signup.component';
import { ManageLeavesComponent } from './manage-leaves/manage-leaves.component';
import { ApplyLeaveComponent } from './apply-leave/apply-leave.component';
import { HistoryComponent } from './history/history.component';
import { HashLocationStrategy } from '@angular/common';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
{ path: "login",  component: LoginComponent,  pathMatch: "full" },
{ path: "signup", component: SignupComponent, pathMatch: "full" },
{ path: "manage", component: ManageLeavesComponent, pathMatch: "full" },
{ path: "apply", component: ApplyLeaveComponent, pathMatch: "full" },
{ path: 'history', component: HistoryComponent, pathMatch: "full" },
{ path: '**', component: HomeComponent, }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
