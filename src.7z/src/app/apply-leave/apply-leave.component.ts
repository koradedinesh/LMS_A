import { Component, OnInit } from '@angular/core';
import { LeaveDetails } from '../model/LeaveDetails';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-apply-leave',
  templateUrl: './apply-leave.component.html',
  styleUrls: ['./apply-leave.component.scss']
})
export class ApplyLeaveComponent implements OnInit {

  startDate: string;
  endDate: string;
  remainingLeaves: number;
  reason: string;

  private showMessage: boolean = false;
  private _success : boolean = false;
  private _message: string;

  get isMessageAvailable() {
    return this.showMessage;
  }

  get success(): boolean {
    return this._success;
  }

  get message() {
    return this._message;
  }

  leaveDetail: LeaveDetails = {
    comment: '',
    leaveFrom: '',
    leaveTo: '',
    reason: '',
    requestId: '',
    status: '',
    submittedOn: '',
    username: '',
    numberOfLeavesApplied: 0
  };

  constructor(private _loginService: LoginService,
    private _router: Router,
    private _http: HttpClient,
    private _datePipe: DatePipe) { }

  ngOnInit(): void {
    if (!this._loginService.isLoggedIn) {
      this._router.navigate(['login']);
    } else {
      this.getRemainingLeaveCount();
    }
  }

  get minDate() {
    return this._datePipe.transform(new Date(), "dd/MM/yyyy");
  }

  get minDate2() {
    return this.leaveDetail.leaveFrom;
  }

  apply() {
    this.leaveDetail.submittedOn = this._datePipe.transform(new Date(), "dd/MM/yyyy");
    this.leaveDetail.leaveFrom = this._datePipe.transform(this.leaveDetail.leaveFrom, "dd/MM/yyyy");
    this.leaveDetail.leaveTo = this._datePipe.transform(this.leaveDetail.leaveTo, "dd/MM/yyyy");

    this._http.post<Map<boolean, String>>("http://localhost:8011/applyForLeave?personId=" + this._loginService.userId, this.leaveDetail)
      .subscribe(response => {
        for (let [k, v] of Object.entries(response)) {
          this._message = v;
          if(k === 'true') {
            this._success = true;
            this.getRemainingLeaveCount();
          } else {
            this._success = false;
          }
          this.showAlert();
          break;
        }
      });
  }

  getRemainingLeaveCount(): void {
    this._http.get<any>("http://localhost:8011/getAvailableLeavesById?personId=" + this._loginService.userId)
      .subscribe(response => {
        this.remainingLeaves = response;
      });
  }

  showAlert(): void {
    this.showMessage = true;
    setTimeout(() => {
      this.showMessage = false;
    }, 5000);
  }

}
