import { Injectable } from '@angular/core';
import { Person} from './model/Person';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private _isLoggedIn: boolean = false;
  private _person: Person;
  get isLoggedIn() {
    return this._isLoggedIn;
  }
  get username() {
    return this._person.username;
  }
  get userId() {
    return this._person.personId;
  }
  get role() {
    return this._person.role;
  }
  constructor() { }
  setLoggedIn(status: boolean) {
    this._isLoggedIn = status;
  }
  setPerson(person: Person): void {
    this._person = person;
    this.setLoggedIn(true);
  }
  endSession(): void {
    this._person = undefined;
    this.setLoggedIn(false);
  }
}
